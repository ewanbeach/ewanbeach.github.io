from graphwarmind import *

#calibrate()
fire()
#getcoords()
