from pyautogui import position
import pickle

def calibrate():
    
    input("Press <Enter> when your mouse is at (25,15).")
    tr=position()
    input("Press <Enter> when your mouse is at (-25,-15).")
    bl=position()
    c=[]
    c.append((tr[0]+bl[0])/2)
    c.append((tr[1]+bl[1])/2)
    
    x=25/(tr[0]-c[0])
    y=15/(tr[1]-c[1])
    d=[x,y]

    with open("calibc.pk", "wb") as fi:
        pickle.dump(c,fi)
    with open("calibd.pk", "wb") as fi:
        pickle.dump(d,fi)

def getcoords():

    with open("calibc.pk","rb") as fi:
        c=pickle.load(fi)
    with open("calibd.pk","rb") as fi:
        d=pickle.load(fi)

    input("Press <Enter> when your mouse is on a game position.")
    p=list(position())
    p[0]=(p[0]-c[0])*d[0]
    p[1]=(p[1]-c[1])*d[1]
    print(p)
    return p

def grabcoords():

    with open("calibc.pk","rb") as fi:
        c=pickle.load(fi)
    with open("calibd.pk","rb") as fi:
        d=pickle.load(fi)   

    p=list(position())
    p[0]=(p[0]-c[0])*d[0]
    p[1]=(p[1]-c[1])*d[1]
    print(p)
    return p

def fire():

    x=[]
    y=[]
    
    while True:
        if input("Press <Enter> when your mouse is on a target (or <.><Enter> on last target).")=="":
            p=grabcoords()
            x.append(p[0])
            y.append(p[1])
        else:
            p=grabcoords()
            x.append(p[0])
            y.append(p[1])
            break

    x=list(map(lambda a : round(a,3),x))
    y=list(map(lambda a : round(a,3),y))
    grads=[]
    for n in range(len(x)-1):
        grads.append((y[n+1]-y[n])/(x[n+1]-x[n]))
    grads=list(map(lambda a : round(a,3),grads))
    
    func=""
    for n in range(len(grads)):
        func=func+"+(%s)*0.5(abs(x-(%s))-abs(x-(%s)))" % (grads[n],x[n],x[n+1])        
    print(func)

