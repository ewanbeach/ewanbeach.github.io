from pyautogui import position
import pickle
    
input("Press <Enter> when your mouse is at the top right of the screen.")
tr=position()
input("Press <Enter> when your mouse is at the bottom left of the screen.")
bl=position()
c=[]
c.append((tr[0]+bl[0])/2)
c.append((tr[1]+bl[1])/2)
    
d=100/(tr[0]-c[0])

x = []
y = []

q = ""
while q in ["","-"]:
    q = input("<Enter> to add cursor point. <-><Enter> to remove last point. <else><Enter> ends sequence.")
    if q == "":
        p=position()
        x.append(round((p[0]-c[0])*d,5))
        y.append(round(-(p[1]-c[1])*d,5))
        print("Point added. Counter = "+str(len(x)))
    elif q == "-":
        x.pop()
        y.pop()
        print("Point removed. Counter = "+str(len(x)))
    else:
        print("Sequence ended. Counter = "+str(len(x)))
        break

print(x)

with open("x_data.pk", "wb") as fi:
    pickle.dump(x,fi)
with open("y_data.pk", "wb") as fi:
    pickle.dump(y,fi)
