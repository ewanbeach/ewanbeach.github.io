import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
from numpy import pi
from math import ceil

r = np.array([5,1,2]) # radii of lines in order
w = np.array([1,2,3]) # measure of angular velocity (completes one revolution of slowest rotation by default)
o = np.array([0,0,0]) # starting angles (radians) in order
time_extend = 1 # scale factor for default time sample
fps = 60 # frames per unit time

def gen_x_dis(t):
    return r*np.cos(w*t+o)
def gen_y_dis(t):
    return r*np.sin(w*t+o)
def accumulate(list):
    list2 = [list[0]]
    for i in range(len(list)-1):
        list2.append(list2[-1]+list[i+1])
    return list2

plot_time=ceil(2*pi/min(np.absolute(w))*time_extend)

fig, ax = plt.subplots()
ax.set(xlim=[-sum(r)*1.2, sum(r)*1.2], ylim=[-sum(r)*1.2, sum(r)*1.2])
ax.set_aspect(1)

t = np.linspace(0, plot_time, num=plot_time*fps+1)
x=np.zeros((len(t),len(r)+1))
y=np.zeros((len(t),len(r)+1))
for n in range(len(t)):
    x[n,1:] = accumulate(gen_x_dis(t[n]))
    y[n,1:] = accumulate(gen_y_dis(t[n]))

curve = ax.plot(x[0,len(r)], y[0,len(r)],"r")[0]
lines = {}
for n in range(1,len(r)+1):
    lines["line{0}".format(n)] = ax.plot(x[0,n-1:n+1], y[0,n-1:n+1],"bo",linestyle="--")[0]

def update(frame):
    curve.set_xdata(x[:frame,len(r)])
    curve.set_ydata(y[:frame,len(r)])
    for n in range(1,len(r)+1):
        lines["line{0}".format(n)].set_xdata(x[frame-1,n-1:n+1])
        lines["line{0}".format(n)].set_ydata(y[frame-1,n-1:n+1])
    return (curve,lines)

ani = animation.FuncAnimation(fig=fig, func=update, frames=plot_time*fps+2, interval=1000/fps, repeat=False)
plt.show()
