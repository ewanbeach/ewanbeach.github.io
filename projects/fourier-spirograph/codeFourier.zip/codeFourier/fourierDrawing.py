import matplotlib.pyplot as plt
import matplotlib.animation as animation
import numpy as np
from numpy import pi,sin,cos
from cmath import phase




# chosen x and y values
px = np.array([0,0,3,3,1,1,3,3,4,4,5,5,6,7,8,9,9,10,10,11,11,14,14,15,15,16,18,18,19,19,18,16,16,15,15,14,14,13,13,12,12,13,13,12,12,11,11,10,10,8,7,6,4,4,3,3,1,1,3,3])
py = np.array([0,5,5,4,4,3,3,2.5,2.5,5,5,1,2.5,4,2.5,1,5,5,2.5,2.5,5,5,2.5,2.5,5,5,2,5,5,0,0,3,0,0,2.5,2.5,0,0,4,4,3,3,2,2,0,0,2.5,2.5,0,0,2,0,0,2.5,2.5,2,2,1,1,0])

c = 1 # eliminate the static line
g = 1 # show tracing target
l = 1 # show drawing lines

s = 0 # use dynamic camera mode
z = 2 # level of zoom on dynamic camera
Tpan = 1 # lower bound on time to pan out camera in seconds

N = 20 # fourier series partial sum index
Tmin = 5 # lower bound on time of plotting in seconds
ppp = 15 # number of plotted points between each chosen point




T = px.size
c0 = complex(sum(px),sum(py))/T

if c:
    px = px-c0.real
    py = py-c0.imag
    c0 = complex(sum(px),sum(py))/T

px = np.append(px,px[0])
py = np.append(py,py[0])

mx = np.zeros(T)
my = np.zeros(T)
for i in range(T):
    mx[i] = px[i+1]-px[i]
    my[i] = py[i+1]-py[i]
m = list(map(complex,mx,my))

w = 2*pi*(np.array(range(2*N+1))-N)/T

def complexp(phase):
    return complex(cos(phase),sin(phase))
expons = list(map(complexp,-w))

def cn(n):
    items = [0]*T
    for i in range(T):
        items[i] = expons[N+n]**i*(m[(i-1)%T]-m[i])
    return sum(items)/T/w[N+n]**2

Cn = [0]*(2*N+1)
Cn[N] = c0
for i in range(N):
    Cn[i] = cn(i-N)
    Cn[2*N-i] = cn(N-i)
r = np.array(list(map(abs,Cn)))
o = np.array(list(map(phase,Cn)))

def gen_x_dis(t):
    return r*cos(w*t+o)
def gen_y_dis(t):
    return r*sin(w*t+o)

t = np.linspace(0, T, num=T*ppp+1)
framecount = len(t)
if l:
    x = np.zeros((framecount,2*N+2))
    y = np.zeros((framecount,2*N+2))

    def accumulate(list):
        list2 = [list[0]]
        for i in range(len(list)-1):
            list2.append(list2[-1]+list[i+1])
        return list2

    for i in range(framecount):
        x[i,1:] = accumulate(gen_x_dis(t[i]))
        y[i,1:] = accumulate(gen_y_dis(t[i]))
else:
    x=np.zeros(framecount)
    y=np.zeros(framecount)

    for i in range(framecount):
        x[i] = sum(gen_x_dis(t[i]))
        y[i] = sum(gen_y_dis(t[i]))

fig, ax = plt.subplots()

ax.set_aspect(1)

xmax = max(px)
xmin = min(px)
ymax = max(py)
ymin = min(py)
xdiff = xmax-xmin
ydiff = ymax-ymin
avdiff = (xdiff+ydiff)/2
ax.set(xlim=[xmin-avdiff*0.25,xmax+avdiff*0.25],
       ylim=[ymin-avdiff*0.25, ymax+avdiff*0.25])

if g:
    trace = ax.plot(px,py,"r--",linewidth=0.75)[0]
if l:
    curve = ax.plot(x[0,2*N+1], y[0,2*N+1],"b",linewidth=3)[0]
    lines = ax.plot(x[0,:],y[0,:],"k",linewidth=0.5,marker="o",markersize=2)[0]
else:
    curve = ax.plot(x[0], y[0],"b",linewidth=3)[0]

if s:
    def update(frame):
        if frame < framecount:
            if l:
                ax.set(xlim=[-avdiff*0.5/z+x[frame,2*N+1], avdiff*0.5/z+x[frame,2*N+1]],
                       ylim=[-avdiff*0.5/z+y[frame,2*N+1], avdiff*0.5/z+y[frame,2*N+1]])
                curve.set_xdata(x[:frame+1,2*N+1])
                curve.set_ydata(y[:frame+1,2*N+1])
                lines.set_xdata(x[frame,:])
                lines.set_ydata(y[frame,:])
                return (curve,lines)
            else:
                ax.set(xlim=[-avdiff*0.5/z+x[frame], avdiff*0.5/z+x[frame]],
                       ylim=[-avdiff*0.5/z+y[frame], avdiff*0.5/z+y[frame]])
                curve.set_xdata(x[:frame+1])
                curve.set_ydata(y[:frame+1])
                return(curve)
        elif frame == framecount:
            if l:
                lines.set_xdata([])
                lines.set_ydata([])
            if g:
                trace.set_xdata([])
                trace.set_ydata([])
        elif frame > framecount:
            if l:
                ax.set(xlim=[-avdiff*0.5/z+x[framecount-1,2*N+1]+(xmin-avdiff*0.25+avdiff*0.5/z-x[framecount-1,2*N+1])*(frame-framecount)/(round(Tpan*framecount/Tmin)),
                             avdiff*0.5/z+x[framecount-1,2*N+1]+(xmax+avdiff*0.25-avdiff*0.5/z-x[framecount-1,2*N+1])*(frame-framecount)/(round(Tpan*framecount/Tmin))],
                       ylim=[-avdiff*0.5/z+y[framecount-1,2*N+1]+(ymin-avdiff*0.25+avdiff*0.5/z-y[framecount-1,2*N+1])*(frame-framecount)/(round(Tpan*framecount/Tmin)),
                             avdiff*0.5/z+y[framecount-1,2*N+1]+(ymax+avdiff*0.25-avdiff*0.5/z-y[framecount-1,2*N+1])*(frame-framecount)/(round(Tpan*framecount/Tmin))])
            else:
                ax.set(xlim=[-avdiff*0.5/z+x[framecount-1]+(xmin-avdiff*0.25+avdiff*0.5/z-x[framecount-1])*(frame-framecount)/(round(Tpan*framecount/Tmin)),
                             avdiff*0.5/z+x[framecount-1]+(xmax+avdiff*0.25-avdiff*0.5/z-x[framecount-1])*(frame-framecount)/(round(Tpan*framecount/Tmin))],
                       ylim=[-avdiff*0.5/z+y[framecount-1]+(ymin-avdiff*0.25+avdiff*0.5/z-y[framecount-1])*(frame-framecount)/(round(Tpan*framecount/Tmin)),
                             avdiff*0.5/z+y[framecount-1]+(ymax+avdiff*0.25-avdiff*0.5/z-y[framecount-1])*(frame-framecount)/(round(Tpan*framecount/Tmin))])
    ani = animation.FuncAnimation(fig=fig, func=update, frames=framecount+round(Tpan*framecount/Tmin), interval=Tmin/framecount*1000, repeat=False)
else:
    def update(frame):
        if l:
            curve.set_xdata(x[:frame+1,2*N+1])
            curve.set_ydata(y[:frame+1,2*N+1])
            lines.set_xdata(x[frame,:])
            lines.set_ydata(y[frame,:])
            return (curve,lines)
        else:
            curve.set_xdata(x[:frame+1])
            curve.set_ydata(y[:frame+1])
            return(curve)

    ani = animation.FuncAnimation(fig=fig, func=update, frames=framecount, interval=Tmin/framecount*1000, repeat=False)
plt.show()
